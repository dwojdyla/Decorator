
public abstract class CodnimentDecorator {
	public abstract String getDescription();
}
