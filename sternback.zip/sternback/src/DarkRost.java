
public class DarkRost extends Beverage{
public DarkRost(){
		description="DarkRost oida";
	}
public double cost(){
	return 1.99;
}
}
